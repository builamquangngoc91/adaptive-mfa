//go:build firebird
// +build firebird

package cli

import (
	_ "github.com/golang-migrate/migrate/v4/database/firebird"
)
