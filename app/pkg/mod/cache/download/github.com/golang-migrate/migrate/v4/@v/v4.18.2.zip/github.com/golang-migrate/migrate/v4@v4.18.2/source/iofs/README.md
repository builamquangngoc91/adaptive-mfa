# iofs

https://pkg.go.dev/github.com/golang-migrate/migrate/v4/source/iofs
