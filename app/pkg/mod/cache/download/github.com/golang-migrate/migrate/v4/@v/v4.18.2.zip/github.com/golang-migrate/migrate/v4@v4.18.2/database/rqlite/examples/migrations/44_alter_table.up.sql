ALTER TABLE pets ADD predator bool;
