//go:build gitlab
// +build gitlab

package cli

import (
	_ "github.com/golang-migrate/migrate/v4/source/gitlab"
)
